#include "Item.h"
#ifdef _DEBUG
#define DBG_NEW new ( NORMAL_BLOCK , __FILE_ , _LINE_ )
// Replace _NORMAL_BLOCK with _CLIENT_BLOCK if you want the
// allocations to be of _CLIENT_BLOCK type
#else
#define DBG_NEW new
#endif

Item::Item()
{
}

Item::Item(ListNode* data, ListNode* myAddress, int serverNumber) : data(data), myAddress(myAddress),serverNumber(serverNumber)
{

}
Item::Item(const Item& other)
{
	setData(other.data);
	setMyAddress(other.myAddress);
	this->serverNumber = other.serverNumber;
}

Item::~Item()
{
}

void Item::setData(ListNode* data)
{
	this->data = data;
}

void Item::setMyAddress(ListNode* myAddress)
{
	this->myAddress = myAddress;
}


ListNode* Item::getData()
{
	return this->data;
}

int Item::getServerNum()
{
	return this->serverNumber;
}


void Item::operator=(const Item& other)
{
	this->myAddress = other.myAddress;
	this->data = other.data;
	this->serverNumber = other.serverNumber;
}

ListNode * Item::getMyAddress()
{
	return this->myAddress;
}
