
#include "Stack.h"
#include <iostream>
#ifdef _DEBUG
#define DBG_NEW new ( NORMAL_BLOCK , __FILE_ , _LINE_ )
// Replace _NORMAL_BLOCK with _CLIENT_BLOCK if you want the
// allocations to be of _CLIENT_BLOCK type
#else
#define DBG_NEW new
#endif

using namespace std;

Stack::Stack()
{
	this->top = nullptr;
}
Stack::~Stack()
{
	makeEmpty();
}
void Stack::makeEmpty()
{
	Node* temp;
	while (this->top != nullptr)
	{
		temp = this->top;
		this->top = this->top->next;
		delete temp;
	}
}

bool Stack::isEmpty()
{
	return (this->top == nullptr);
}
void Stack::push(const Item& toAdd)
{
	this->top = new Node(toAdd, this->top);
}
const Item Stack::pop()
{
	if (isEmpty())
	{
		Item p(nullptr,nullptr,0);
		cout << "Stack Is Empty";
		return p;////
	}
		
	else
	{
		Node* temp = this->top;
		Item p = this->top->data;
		this->top = this->top->next;
		delete temp;
		return p;
	}
}

