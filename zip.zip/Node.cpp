
#include "Node.h"
#ifdef _DEBUG
#define DBG_NEW new ( NORMAL_BLOCK , __FILE_ , _LINE_ )
// Replace _NORMAL_BLOCK with _CLIENT_BLOCK if you want the
// allocations to be of _CLIENT_BLOCK type
#else
#define DBG_NEW new
#endif

Node::Node(const Item& item)
{
	this->data = data;
	next = nullptr;
}
Node::Node(const Item& data, Node* next)
{
	this->data = data;
	this->next = next;
}
Node::Node(const Node& other)
{
	this->data = other.data;
	this->next = other.next;
}

Node::~Node()
{
	
}
void Node::insertAfter(Node* newnode)
{
	newnode->next = this->next;
	this->next = newnode;
}
Node*Node::DeleteAfter(void)
{
	Node* temp = next;
	if (this->next == nullptr)
		return nullptr;

	next = temp->next;
	return temp;
}
